package com.example.sw04.loginexample;

import com.amazonaws.mobileconnectors.lambdainvoker.LambdaFunction;

/**
 * Created by sw04 on 2018-05-09.
 */

public interface LogInInterface {
    @LambdaFunction
    LogInResponseClass AddingStoreLogIn(LogInRequestClass request);
}
