package com.example.sw04.loginexample;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.lambdainvoker.LambdaFunctionException;
import com.amazonaws.mobileconnectors.lambdainvoker.LambdaInvokerFactory;
import com.amazonaws.regions.Regions;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText idEditor = (EditText)findViewById(R.id.idEditor);
        final EditText pwEditor = (EditText)findViewById(R.id.pwEditor) ;
        Button logInButton = (Button)findViewById(R.id.logInButton);

        // Amazon Cognito 인증 공급자, 인증 공급자가 있어야먄 아마존 서비스를 이용할 수 있다.
        CognitoCachingCredentialsProvider cognitoProvider = new CognitoCachingCredentialsProvider(
                getApplicationContext(),
                "ap-northeast-2:a03da40d-6e0a-40f9-9510-6a5fb5c4a37a",
                Regions.AP_NORTHEAST_2
        );

        // 인증 공급자로 인증을 받아 람다 기동자 인터페이스를 지어주는 기동자 제작소를 만든다.
        LambdaInvokerFactory factory = new LambdaInvokerFactory(this.getApplicationContext(), Regions.AP_NORTHEAST_2, cognitoProvider);

        // 제작소에서 람다 기동자 인터페이스를 짓는다.
        final LogInInterface logInInterface = factory.build(LogInInterface.class);

        // 로그인 버튼을 눌렀을 때 다음과 같은 반응을 한다.
        logInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 안드로이드는 외부에서 반응을 기다려야 하는 동작은 메인쓰레드에서 실행하지 못하도록 막고있다.
                // 아마존 매뉴얼에서는 이 이슈에 대해 비동기 쓰레드를 만드는 코드를 제시하고 있다.
                // 다만 이 방법은 반응시간이 길면 메모리 누수가 일어날 수 있다는 듯 하므로 그 외의 현명한 방법을 안다면 그 방법으로 해주길 바람.
                new AsyncTask<LogInRequestClass, Void, LogInResponseClass>() {
                    @Override
                    protected LogInResponseClass doInBackground(LogInRequestClass... params) {
                        try {
                            // 아마존 람다를 실행하기 위한 코드는 리턴문에 적혀있는 함수이다. 인자 params[0]는 excute()에서 받아온 인자를 의미한다.
                            return logInInterface.AddingStoreLogIn(params[0]);
                        } catch (LambdaFunctionException lfe) {
                            Log.e("Tag", "Failed to invoke echo", lfe);
                            return null;
                        }
                    }

                    @Override
                    protected void onPostExecute(LogInResponseClass result) {
                        // doInBackground()함수의 리턴값이 이 함수의 인자이다. 로그인 성공 여부는 이 값에 따라 결정된다.
                        if (result.getResult() == true) {
                            Toast.makeText(getApplicationContext(), "성공", Toast.LENGTH_LONG).show();
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "실패", Toast.LENGTH_LONG).show();
                        }
                    }
                }.execute(new LogInRequestClass(idEditor.getText().toString(), pwEditor.getText().toString()));
            }
        });
    }
}
