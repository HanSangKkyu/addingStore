package com.example.sw04.loginexample;

/**
 * Created by sw04 on 2018-05-09.
 */

public class LogInResponseClass {
    boolean result;

    public boolean getResult() {
        return result;
    }

    public boolean setResult() {
        return result;
    }
    public LogInResponseClass(boolean result) {
        this.result = result;
    }
    public LogInResponseClass() {
    }
}
